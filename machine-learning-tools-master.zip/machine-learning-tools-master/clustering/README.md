Three diﬀerent clustering methods, K-means, Kernel K-means and Gaussian Mixture Model. 
Evaluating the performance of your method on two synthetic datasets.

# Data  
Two datasets, blob.csv and circle.csv. Both datasets have two dimensions.

# K-means  
The algorithm runs for diﬀerent values of K ∈{2,3,5}, and plots the clustering assignments by diﬀerent colors and markers. 

#  Kernel k-means  
The algorithm runs for diﬀerent values of K ∈{2,3,5}, and plots the clustering assignments by diﬀerent colors and markers and works with circle.csv

# Gaussian Mixture Model
EM algorithm to ﬁt a Gaussian Mixture model on the blob.csv dataset
Runs for K=3
